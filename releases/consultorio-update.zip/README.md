Consultório Psicologia — V27.1.0 (teste)

Correções desta versão:
- O filtro de datas continua alterando os totais Devido e Recebido exibidos, mas o Saldo permanece global, calculado sobre todas as sessões passadas cobráveis e todos os pagamentos registrados do paciente.
- Os gráficos anuais ficam empilhados e compactados para caber na largura de telas de notebook de 14 polegadas.
- O instalador preserva o banco de dados local existente ao reinstalar; só copia o banco inicial se ainda não houver um.

Instale sobre a versão de teste V27. Feche a aplicação antes de executar INSTALAR.bat. A instalação da Nathalia não deve ser atualizada antes da validação.

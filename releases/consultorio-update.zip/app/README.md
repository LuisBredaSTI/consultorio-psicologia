Consultório de Psicologia — V27.0.0

Aplicativo local. O banco de dados fica separado do código, em data/consultorio.db, e não é incluído no pacote de atualização.

const http = require('http');
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = process.env.CONSULTORIO_DATA_DIR || path.join(ROOT, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'consultorio.db'));
db.exec('PRAGMA foreign_keys = ON');

function columnExists(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === column);
}
function addColumn(table, column, definition) {
  if (!columnExists(table, column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}
addColumn('sessions', 'rescheduled_to_id', 'INTEGER');
addColumn('sessions', 'rescheduled_from_id', 'INTEGER');
addColumn('sessions', 'slot_removed', 'INTEGER DEFAULT 0');
addColumn('sessions', 'created_at', 'TEXT');
addColumn('patients', 'active', 'INTEGER DEFAULT 1');
addColumn('patients', 'weekday', 'INTEGER');
addColumn('patients', 'habitual_time', 'TEXT');

db.exec(`CREATE TABLE IF NOT EXISTS agenda_locks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lock_date TEXT NOT NULL,
  start_time TEXT,
  end_time TEXT,
  reason TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);
db.exec('CREATE INDEX IF NOT EXISTS idx_sessions_date_time ON sessions(session_date, session_time)');
db.exec('CREATE INDEX IF NOT EXISTS idx_sessions_patient_date ON sessions(patient_id, session_date)');
db.exec('CREATE INDEX IF NOT EXISTS idx_locks_date_time ON agenda_locks(lock_date, start_time)');
db.exec(`CREATE TABLE IF NOT EXISTS personal_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_date TEXT NOT NULL,
  event_time TEXT NOT NULL,
  title TEXT NOT NULL,
  notes TEXT,
  series_id INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);
addColumn('personal_events', 'series_id', 'INTEGER');
db.exec('UPDATE personal_events SET series_id=id WHERE series_id IS NULL');

db.exec('CREATE INDEX IF NOT EXISTS idx_personal_events_date_time ON personal_events(event_date, event_time)');
db.exec(`CREATE TABLE IF NOT EXISTS financial_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL CHECK(type IN ('receber','pagar')),
  description TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  due_date TEXT,
  paid_date TEXT,
  status TEXT NOT NULL DEFAULT 'Aberto',
  patient_id INTEGER,
  notes TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE SET NULL
)`);
db.exec('CREATE INDEX IF NOT EXISTS idx_financial_entries_type_date ON financial_entries(type,due_date)');


db.exec(`CREATE TABLE IF NOT EXISTS patient_attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
  size INTEGER NOT NULL DEFAULT 0,
  data BLOB NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
)`);
db.exec('CREATE INDEX IF NOT EXISTS idx_patient_attachments_patient ON patient_attachments(patient_id, created_at)');

db.exec(`CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
function setting(key, fallback){ const r=get('SELECT value FROM app_settings WHERE key=?',key); return r ? r.value : fallback; }

const STATUSES = ['Agendada','Realizada','Cancelada antecipadamente','Cancelada em cima da hora','Faltou'];
const BILLABLE = new Set(['Realizada','Cancelada em cima da hora','Faltou']);
const json = (res, status, data) => { const body = JSON.stringify(data); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(body); };
const all = (sql, ...params) => db.prepare(sql).all(...params);
const get = (sql, ...params) => db.prepare(sql).get(...params);
async function body(req) { let data=''; for await (const chunk of req) data += chunk; return data ? JSON.parse(data) : {}; }
const nowIso = () => new Date().toISOString();
function isoDate(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
const money = v => Number(v || 0);
const xmlEsc = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const excelCell = (value, type='String') => `<Cell><Data ss:Type="${type}">${xmlEsc(value)}</Data></Cell>`;
function excelXml(workbookName, sheets){
  const rows=sheets.map(sh=>`<Worksheet ss:Name="${xmlEsc(sh.name)}"><Table>${sh.rows.map(r=>`<Row>${r.map(c=>excelCell(c.value,c.type||'String')).join('')}</Row>`).join('')}</Table></Worksheet>`).join('');
  return `<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Title>${xmlEsc(workbookName)}</Title></DocumentProperties>${rows}</Workbook>`;
}



function isLocked(date, time=null) {
  const day = get('SELECT * FROM agenda_locks WHERE lock_date=? AND start_time IS NULL LIMIT 1', date);
  if (day) return day;
  if (time) return get('SELECT * FROM agenda_locks WHERE lock_date=? AND start_time=? LIMIT 1', date, time);
  return null;
}
function sessionById(id) {
  return get(`SELECT s.*, p.name AS patient_name, p.whatsapp, p.fee AS patient_fee
              FROM sessions s JOIN patients p ON p.id=s.patient_id WHERE s.id=?`, id);
}
function sessionForDateTime(date,time){
  return get(`SELECT s.* FROM sessions s WHERE s.session_date=? AND s.session_time=? AND COALESCE(s.slot_removed,0)=0 LIMIT 1`,date,time);
}
function checkCollision(date, time, ignoreId=null) {
  if (!time) return null;
  const lock = isLocked(date, time); if (lock) return {type:'lock', lock};
  let sql=`SELECT s.*, p.name AS patient_name FROM sessions s JOIN patients p ON p.id=s.patient_id
           WHERE s.session_date=? AND s.session_time=? AND COALESCE(s.slot_removed,0)=0`;
  const params=[date,time];
  if (ignoreId) { sql += ' AND s.id<>?'; params.push(ignoreId); }
  const s=get(sql,...params); return s ? {type:'session',session:s} : null;
}
function normalizeValue(b, patientId) {
  if (b.valor !== undefined && b.valor !== null && b.valor !== '') return money(b.valor);
  const p=get('SELECT fee FROM patients WHERE id=?', patientId); return money(p?.fee);
}
function patientFinancials() {
  return all(`SELECT p.*,
    COALESCE((SELECT SUM(CASE WHEN s.status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN s.value ELSE 0 END)
              FROM sessions s WHERE s.patient_id=p.id),0) AS total_due,
    COALESCE((SELECT SUM(pg.amount) FROM payments pg WHERE pg.patient_id=p.id),0) AS total_paid,
    COALESCE((SELECT SUM(CASE WHEN s.status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN s.value ELSE 0 END)
              FROM sessions s WHERE s.patient_id=p.id),0)
      - COALESCE((SELECT SUM(pg.amount) FROM payments pg WHERE pg.patient_id=p.id),0) AS pending
    FROM patients p ORDER BY p.name`);
}


function billableSessions() {
  return all(`SELECT s.*, p.name AS patient_name, p.whatsapp
              FROM sessions s JOIN patients p ON p.id=s.patient_id
              WHERE s.status IN ('Realizada','Cancelada em cima da hora','Faltou')
              ORDER BY s.patient_id, s.session_date, COALESCE(s.session_time,'00:00'), s.id`);
}
function unpaidSessionRows() {
  const sessions=billableSessions();
  const payments=all(`SELECT patient_id, payment_date, amount, id FROM payments ORDER BY patient_id, payment_date, id`);
  const byPatient=new Map();
  for(const p of payments){
    if(!byPatient.has(p.patient_id)) byPatient.set(p.patient_id,[]);
    byPatient.get(p.patient_id).push({...p, remaining:Number(p.amount||0)});
  }
  const out=[];
  for(const s of sessions){
    let remaining=Number(s.value||0);
    const ps=byPatient.get(s.patient_id)||[];
    for(const p of ps){
      if(remaining<=0) break;
      const used=Math.min(remaining,p.remaining);
      remaining-=used; p.remaining-=used;
    }
    if(remaining>0.005) out.push({...s, remaining:Math.round(remaining*100)/100});
  }
  return out;
}

async function api(req,res,url) {
  try {
    if (url.pathname==='/api/health' && req.method==='GET') return json(res,200,{ok:true,runtime:'Node.js',sqlite:'node:sqlite',version:'15.0.0'});

    // Patients
    if (url.pathname==='/api/pacientes' && req.method==='GET') {
      const q=(url.searchParams.get('q')||'').trim();
      const status=url.searchParams.get('status')||'ativos';
      let where=[]; const params=[];
      if (q) { where.push('(p.name LIKE ? OR p.whatsapp LIKE ? OR printf("%.2f",p.fee) LIKE ? OR p.habitual_time LIKE ?)'); params.push(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`); }
      if (status==='ativos') where.push('COALESCE(p.active,1)=1');
      if (status==='inativos') where.push('COALESCE(p.active,1)=0');
      const sql=`SELECT p.*,
        COALESCE((SELECT SUM(CASE WHEN s.status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN s.value ELSE 0 END) FROM sessions s WHERE s.patient_id=p.id),0) AS total_due,
        COALESCE((SELECT SUM(pg.amount) FROM payments pg WHERE pg.patient_id=p.id),0) AS total_paid,
        COALESCE((SELECT SUM(CASE WHEN s.status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN s.value ELSE 0 END) FROM sessions s WHERE s.patient_id=p.id),0)
          - COALESCE((SELECT SUM(pg.amount) FROM payments pg WHERE pg.patient_id=p.id),0) AS pending
        FROM patients p ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY p.name`;
      return json(res,200,all(sql,...params));
    }
    if (url.pathname==='/api/pacientes' && req.method==='POST') {
      const b=await body(req);
      if(!String(b.nome||'').trim() || b.valor_sessao==null || b.dia_preferencial==null || !b.horario_preferencial) return json(res,400,{error:'Nome, valor da sessão, dia e horário preferencial são obrigatórios'});
      const fee=money(b.valor_sessao), weekday=Number(b.dia_preferencial);
      if(!Number.isInteger(weekday)||weekday<0||weekday>6) return json(res,400,{error:'Dia da semana inválido'});
      const info=db.prepare(`INSERT INTO patients (name,whatsapp,email,fee,frequency,weekday,habitual_time,active,notes) VALUES (?,?,?,?,?,?,?,?,?)`)
        .run(String(b.nome).trim(),b.telefone||null,b.email||null,fee,b.frequencia||'Semanal',weekday,b.horario_preferencial,1,b.observacoes||null);
      return json(res,201,get('SELECT * FROM patients WHERE id=?',info.lastInsertRowid));
    }
    let m=url.pathname.match(/^\/api\/pacientes\/(\d+)$/);
    if(m && req.method==='GET') {
      const p=get('SELECT * FROM patients WHERE id=?',m[1]); if(!p) return json(res,404,{error:'Paciente não encontrado'});
      return json(res,200,{paciente:p,sessoes:all('SELECT * FROM sessions WHERE patient_id=? ORDER BY session_date DESC, session_time DESC',m[1]),pagamentos:all('SELECT * FROM payments WHERE patient_id=? ORDER BY payment_date DESC',m[1]),anexos:all('SELECT id,patient_id,filename,mime_type,size,created_at FROM patient_attachments WHERE patient_id=? ORDER BY created_at DESC,id DESC',m[1])});
    }
    if(m && req.method==='PATCH') {
      const p=get('SELECT * FROM patients WHERE id=?',m[1]); if(!p) return json(res,404,{error:'Paciente não encontrado'});
      const b=await body(req);
      const name=b.nome!==undefined?String(b.nome).trim():p.name;
      const phone=b.telefone!==undefined?b.telefone:p.whatsapp;
      const fee=b.valor_sessao!==undefined?money(b.valor_sessao):p.fee;
      const weekday=b.dia_preferencial!==undefined?Number(b.dia_preferencial):p.weekday;
      const time=b.horario_preferencial!==undefined?b.horario_preferencial:p.habitual_time;
      const active=b.active!==undefined?Number(!!b.active):Number(p.active??1);
      db.prepare(`UPDATE patients SET name=?, whatsapp=?, fee=?, weekday=?, habitual_time=?, active=?, notes=? WHERE id=?`)
        .run(name,phone,fee,weekday,time,active,b.observacoes!==undefined?b.observacoes:p.notes,m[1]);
      return json(res,200,get('SELECT * FROM patients WHERE id=?',m[1]));
    }

    // Patient report (Excel-compatible .xls with two worksheets)
    if(url.pathname==='/api/relatorio-pacientes' && req.method==='GET') {
      const from=(url.searchParams.get('from')||'').trim();
      const params=[];
      const patientRows=all('SELECT id,name,whatsapp,fee,active FROM patients ORDER BY name COLLATE NOCASE');
      let sessionSql=`SELECT s.patient_id,s.session_date,s.session_time,p.name AS patient_name,s.status,s.notes,s.value FROM sessions s JOIN patients p ON p.id=s.patient_id`;
      let paymentSql=`SELECT pg.patient_id,pg.payment_date,p.name AS patient_name,pg.notes,pg.amount FROM payments pg JOIN patients p ON p.id=pg.patient_id`;
      if(from){sessionSql+=' WHERE s.session_date>=?';paymentSql+=' WHERE pg.payment_date>=?';params.push(from)}
      sessionSql+=' ORDER BY p.name COLLATE NOCASE,s.session_date,s.session_time,s.id';
      const sessionParams=from?[from]:[];
      paymentSql+=' ORDER BY p.name COLLATE NOCASE,pg.payment_date,pg.id';
      const sessionRows=all(sessionSql,...sessionParams), paymentRows=all(paymentSql,...(from?[from]:[]));
      const sessionsBy=new Map(), paymentsBy=new Map();
      for(const r of sessionRows){if(!sessionsBy.has(r.patient_id))sessionsBy.set(r.patient_id,[]);sessionsBy.get(r.patient_id).push(r)}
      for(const r of paymentRows){if(!paymentsBy.has(r.patient_id))paymentsBy.set(r.patient_id,[]);paymentsBy.get(r.patient_id).push(r)}
      const sRows=[[['Nome'],['Data sessão'],['Horário'],['Status'],['Observação'],['Valor']]];
      const sOut=[['Nome','Data sessão','Horário','Status','Observação','Valor'].map(v=>({value:v}))];
      for(const p of patientRows){const rows=sessionsBy.get(p.id)||[]; for(const r of rows)sOut.push([{value:p.name},{value:r.session_date},{value:r.session_time||''},{value:r.status},{value:r.notes||''},{value:Number(r.value||0),type:'Number'}])}
      const payOut=[['Nome','Data pagamento','Observação','Valor'].map(v=>({value:v}))];
      for(const p of patientRows){const rows=paymentsBy.get(p.id)||[]; for(const r of rows)payOut.push([{value:p.name},{value:r.payment_date},{value:r.notes||''},{value:Number(r.amount||0),type:'Number'}])}
      const xml=excelXml('Relatório de pacientes',[{name:'Atendimentos',rows:sOut},{name:'Pagamentos',rows:payOut}]);
      res.writeHead(200,{'Content-Type':'application/vnd.ms-excel; charset=utf-8','Content-Disposition':`attachment; filename="relatorio-pacientes.xls"`,'Cache-Control':'no-store'});res.end(xml);return;
    }
    // Patient attachments stored as BLOBs in SQLite
    let am=url.pathname.match(/^\/api\/pacientes\/(\d+)\/anexos$/);
    if(am && req.method==='GET') {
      const pid=Number(am[1]); if(!get('SELECT id FROM patients WHERE id=?',pid)) return json(res,404,{error:'Paciente não encontrado'});
      return json(res,200,all('SELECT id,patient_id,filename,mime_type,size,created_at FROM patient_attachments WHERE patient_id=? ORDER BY created_at DESC,id DESC',pid));
    }
    if(am && req.method==='POST') {
      const pid=Number(am[1]); if(!get('SELECT id FROM patients WHERE id=?',pid)) return json(res,404,{error:'Paciente não encontrado'});
      const b=await body(req); if(!b.filename||!b.data) return json(res,400,{error:'Arquivo e dados são obrigatórios'});
      const raw=String(b.data).replace(/^data:[^;]+;base64,/,''); const buf=Buffer.from(raw,'base64');
      if(!buf.length) return json(res,400,{error:'Arquivo vazio'}); if(buf.length>20*1024*1024) return json(res,413,{error:'Arquivo maior que 20 MB'});
      const info=db.prepare('INSERT INTO patient_attachments (patient_id,filename,mime_type,size,data) VALUES (?,?,?,?,?)').run(pid,String(b.filename).slice(0,255),String(b.mime_type||'application/octet-stream'),buf.length,buf);
      return json(res,201,get('SELECT id,patient_id,filename,mime_type,size,created_at FROM patient_attachments WHERE id=?',info.lastInsertRowid));
    }
    let ax=url.pathname.match(/^\/api\/anexos\/(\d+)$/);
    if(ax && req.method==='GET') {
      const a=get('SELECT * FROM patient_attachments WHERE id=?',Number(ax[1])); if(!a)return json(res,404,{error:'Arquivo não encontrado'});
      const safe=String(a.filename).replace(/[\\\"\r\n]/g,'_');res.writeHead(200,{'Content-Type':a.mime_type||'application/octet-stream','Content-Length':a.size,'Content-Disposition':`attachment; filename="${safe}"`,'Cache-Control':'no-store'});res.end(Buffer.from(a.data));return;
    }
    if(ax && req.method==='DELETE') {db.prepare('DELETE FROM patient_attachments WHERE id=?').run(Number(ax[1]));return json(res,200,{ok:true});}

    // Agenda
    if(url.pathname==='/api/agenda' && req.method==='GET') {
      const start=url.searchParams.get('start'), end=url.searchParams.get('end');
      if(!start||!end) return json(res,400,{error:'start e end são obrigatórios'});
      const sessoes=all(`SELECT s.*, p.name AS patient_name, p.whatsapp, p.fee AS patient_fee
        FROM sessions s JOIN patients p ON p.id=s.patient_id
        WHERE s.session_date BETWEEN ? AND ? ORDER BY s.session_date, s.session_time, p.name`,start,end);
      const locks=all('SELECT * FROM agenda_locks WHERE lock_date BETWEEN ? AND ? ORDER BY lock_date,start_time',start,end);
      const eventos=all('SELECT * FROM personal_events WHERE event_date BETWEEN ? AND ? ORDER BY event_date,event_time,title',start,end);
      return json(res,200,{sessoes,locks,eventos});
    }
    if(url.pathname==='/api/sessoes' && req.method==='GET') {
      const mes=url.searchParams.get('mes'); let sql='SELECT s.*, p.name AS patient_name FROM sessions s JOIN patients p ON p.id=s.patient_id';
      if(mes) sql+=' WHERE substr(s.session_date,1,7)=?'; sql+=' ORDER BY s.session_date, s.session_time, p.name';
      return json(res,200,mes?all(sql,mes):all(sql));
    }
    if(url.pathname==='/api/sessoes' && req.method==='POST') {
      const b=await body(req); if(!b.patient_id||!b.data||!b.status) return json(res,400,{error:'patient_id, data e status são obrigatórios'});
      if(!STATUSES.includes(b.status)) return json(res,400,{error:'Status inválido'});
      const collision=checkCollision(b.data,b.horario||null); if(collision) return json(res,409,{error:collision.type==='lock'?`Horário travado: ${collision.lock.reason}`:`Horário já ocupado por ${collision.session.patient_name}`});
      const value=normalizeValue(b,b.patient_id);
      const info=db.prepare('INSERT INTO sessions (patient_id,session_date,session_time,status,value,notes,slot_removed,created_at) VALUES (?,?,?,?,?,?,0,?)').run(b.patient_id,b.data,b.horario||null,b.status,value,b.observacao||null,nowIso());
      return json(res,201,sessionById(info.lastInsertRowid));
    }
    let rm=url.pathname.match(/^\/api\/sessoes\/(\d+)\/reagendar$/);
    if(rm && req.method==='POST') {
      const id=Number(rm[1]); const old=sessionById(id); if(!old) return json(res,404,{error:'Sessão não encontrada'});
      const b=await body(req); const newDate=b.data,newTime=b.horario;
      if(!newDate||!newTime) return json(res,400,{error:'Nova data e horário são obrigatórios'});
      const collision=checkCollision(newDate,newTime); if(collision) return json(res,409,{error:collision.type==='lock'?`Horário travado: ${collision.lock.reason}`:`Horário já ocupado por ${collision.session.patient_name}`});
      const info=db.prepare('INSERT INTO sessions (patient_id,session_date,session_time,status,value,notes,slot_removed,created_at,rescheduled_from_id) VALUES (?,?,?,?,?,?,0,?,?)').run(old.patient_id,newDate,newTime,'Agendada',old.value,old.notes||null,nowIso(),id);
      db.prepare('UPDATE sessions SET rescheduled_to_id=?, slot_removed=1 WHERE id=?').run(info.lastInsertRowid,id);
      return json(res,201,{original:sessionById(id),nova:sessionById(info.lastInsertRowid)});
    }
    rm=url.pathname.match(/^\/api\/sessoes\/(\d+)\/sem-reagendamento$/);
    if(rm && req.method==='POST') { const id=Number(rm[1]); const s=sessionById(id); if(!s) return json(res,404,{error:'Sessão não encontrada'}); db.prepare('UPDATE sessions SET slot_removed=1 WHERE id=?').run(id); return json(res,200,sessionById(id)); }
    m=url.pathname.match(/^\/api\/sessoes\/(\d+)$/);
    if(m && req.method==='PATCH') {
      const id=Number(m[1]); const old=sessionById(id); if(!old) return json(res,404,{error:'Sessão não encontrada'});
      const b=await body(req); const date=b.data??old.session_date, time=b.horario??old.session_time, status=b.status??old.status;
      if(!STATUSES.includes(status)) return json(res,400,{error:'Status inválido'});
      if((date!==old.session_date || time!==old.session_time) && ['Realizada','Faltou'].includes(old.status)) return json(res,409,{error:'Sessões Realizada e Faltou não podem ser remanejadas.'});
      if(isLocked(date,time) && (date!==old.session_date || time!==old.session_time || b.status!==undefined)) return json(res,409,{error:'Este horário está travado'});
      const collision=checkCollision(date,time,id); if(collision) return json(res,409,{error:collision.type==='lock'?`Horário travado: ${collision.lock.reason}`:`Horário já ocupado por ${collision.session.patient_name}`});
      const value=b.valor!==undefined?money(b.valor):old.value;
      const slotRemoved=b.slot_removed!==undefined?Number(!!b.slot_removed):Number(old.slot_removed||0);
      db.prepare('UPDATE sessions SET session_date=?,session_time=?,status=?,value=?,notes=?,slot_removed=? WHERE id=?').run(date,time,status,value,b.observacao!==undefined?b.observacao:old.notes,slotRemoved,id);
      return json(res,200,sessionById(id));
    }

    // Popular agenda a partir do cadastro dos pacientes
    if(url.pathname==='/api/agenda/popular' && req.method==='POST') {
      const b=await body(req); const inicio=b.inicio||new Date().toISOString().slice(0,10), fim=b.fim;
      if(!fim) return json(res,400,{error:'Data final é obrigatória'});
      if(inicio>fim) return json(res,400,{error:'A data final não pode ser anterior à inicial'});
      const patients=all(`SELECT * FROM patients WHERE COALESCE(active,1)=1 AND weekday IS NOT NULL AND habitual_time IS NOT NULL AND habitual_time<>'' ORDER BY name`);
      let created=0, skipped=0, dt=new Date(inicio+'T12:00:00'), last=new Date(fim+'T12:00:00');
      while(dt<=last){
        const d=dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');
        const dow=dt.getDay();
        for(const p of patients.filter(x=>Number(x.weekday)===dow)){
          if(isLocked(d,p.habitual_time) || sessionForDateTime(d,p.habitual_time) || get('SELECT 1 FROM personal_events WHERE event_date=? AND event_time=? LIMIT 1',d,p.habitual_time)){ skipped++; continue; }
          db.prepare('INSERT INTO sessions (patient_id,session_date,session_time,status,value,notes,slot_removed,created_at) VALUES (?,?,?,?,?,?,0,?)').run(p.id,d,p.habitual_time,'Agendada',p.fee,null,nowIso());
          created++;
        }
        dt.setDate(dt.getDate()+1);
      }
      return json(res,201,{created,skipped});
    }
    // Personal events
    if(url.pathname==='/api/eventos' && req.method==='POST') {
      const b=await body(req);
      if(!b.data||!b.horario||!String(b.titulo||'').trim()) return json(res,400,{error:'Data, horário e título são obrigatórios'});
      if(isLocked(b.data,b.horario)) return json(res,409,{error:'Este horário está travado'});
      if(checkCollision(b.data,b.horario)) return json(res,409,{error:`Horário já ocupado por ${checkCollision(b.data,b.horario).session?.patient_name||'uma sessão'}`});
      const repeat=!!b.repetir;
      const count=repeat?Math.max(1,Math.min(52,Number(b.semanas||16))):1;
      let created=[];
      let seriesId=null;
      for(let i=0;i<count;i++){
        const dt=new Date(b.data+'T12:00:00');
        dt.setDate(dt.getDate()+i*7);
        const d=dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');
        if(isLocked(d,b.horario)) { if(!repeat) return json(res,409,{error:'Este horário está travado'}); continue; }
        const collision=checkCollision(d,b.horario);
        if(collision) { if(!repeat) return json(res,409,{error:`Horário já ocupado em ${d}`}); continue; }
        const info=db.prepare('INSERT INTO personal_events (event_date,event_time,title,notes,series_id) VALUES (?,?,?,?,NULL)')
          .run(d,b.horario,String(b.titulo).trim(),b.observacao||null);
        if(seriesId===null) seriesId=Number(info.lastInsertRowid);
        db.prepare('UPDATE personal_events SET series_id=? WHERE id=?').run(seriesId,info.lastInsertRowid);
        created.push(get('SELECT * FROM personal_events WHERE id=?',info.lastInsertRowid));
      }
      return json(res,201,{eventos:created,series_id:seriesId});
    }
    m=url.pathname.match(/^\/api\/eventos\/(\d+)$/);
    if(m && req.method==='DELETE') {
      const ev=get('SELECT * FROM personal_events WHERE id=?',m[1]);
      if(!ev) return json(res,404,{error:'Compromisso não encontrado'});
      const scope=url.searchParams.get('scope')||'one';
      if(scope==='series' && ev.series_id) db.prepare('DELETE FROM personal_events WHERE series_id=?').run(ev.series_id);
      else db.prepare('DELETE FROM personal_events WHERE id=?').run(m[1]);
      return json(res,200,{ok:true,scope});
    }

    // Locks
    if(url.pathname==='/api/travar' && req.method==='POST') {
      const b=await body(req);
      const startDate=b.inicio||b.data, endDate=b.fim||b.data;
      if(!startDate||!endDate||!b.motivo) return json(res,400,{error:'Data inicial, data final e motivo são obrigatórios'});
      if(startDate>endDate) return json(res,400,{error:'A data final não pode ser anterior à inicial'});
      const start=b.horario||null, end=b.horario||null, created=[];
      let dt=new Date(startDate+'T12:00:00'), last=new Date(endDate+'T12:00:00');
      while(dt<=last){
        const d=dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0');
        if(!isLocked(d,start)){
          const info=db.prepare('INSERT INTO agenda_locks (lock_date,start_time,end_time,reason) VALUES (?,?,?,?)').run(d,start,end,b.motivo);
          created.push(get('SELECT * FROM agenda_locks WHERE id=?',info.lastInsertRowid));
        }
        dt.setDate(dt.getDate()+1);
      }
      return json(res,201,{locks:created});
    }
    m=url.pathname.match(/^\/api\/travar\/(\d+)$/);
    if(m && req.method==='DELETE') { db.prepare('DELETE FROM agenda_locks WHERE id=?').run(m[1]); return json(res,200,{ok:true}); }

    // Finance session launch editing: historical billable sessions are editable from Financeiro.
    let fm=url.pathname.match(/^\/api\/financeiro\/sessoes\/(\d+)$/);
    if(fm && req.method==='PATCH') {
      const id=Number(fm[1]); const old=sessionById(id);
      if(!old) return json(res,404,{error:'Lançamento de sessão não encontrado'});
      const b=await body(req);
      const patientId=b.patient_id!==undefined?Number(b.patient_id):old.patient_id;
      const date=b.data!==undefined?String(b.data):old.session_date;
      const time=b.horario!==undefined?(b.horario||null):old.session_time;
      const status=b.status!==undefined?String(b.status):old.status;
      if(!STATUSES.includes(status)) return json(res,400,{error:'Status inválido'});
      if(!patientId) return json(res,400,{error:'Paciente é obrigatório'});
      if(!date) return json(res,400,{error:'Data é obrigatória'});
      if((date!==old.session_date || time!==old.session_time) && isLocked(date,time)) return json(res,409,{error:'Este horário está travado'});
      const collision=checkCollision(date,time,id);
      if(collision) return json(res,409,{error:collision.type==='lock'?`Horário travado: ${collision.lock.reason}`:`Horário já ocupado por ${collision.session.patient_name}`});
      const value=b.valor!==undefined?money(b.valor):old.value;
      db.prepare('UPDATE sessions SET patient_id=?,session_date=?,session_time=?,status=?,value=?,notes=? WHERE id=?').run(patientId,date,time,status,value,b.observacao!==undefined?b.observacao:old.notes,id);
      return json(res,200,sessionById(id));
    }

    // Payments
    if(url.pathname==='/api/pagamentos' && req.method==='GET') {
      const mes=url.searchParams.get('mes'); let sql='SELECT pg.*, p.name AS patient_name FROM payments pg JOIN patients p ON p.id=pg.patient_id';
      if(mes) sql+=' WHERE substr(pg.payment_date,1,7)=?'; sql+=' ORDER BY pg.payment_date DESC, p.name'; return json(res,200,mes?all(sql,mes):all(sql));
    }
    if(url.pathname==='/api/pagamentos' && req.method==='POST') {
      const b=await body(req); if(!b.patient_id||!b.data||b.valor==null) return json(res,400,{error:'patient_id, data e valor são obrigatórios'});
      const info=db.prepare('INSERT INTO payments (patient_id,payment_date,amount,notes) VALUES (?,?,?,?)').run(b.patient_id,b.data,money(b.valor),b.observacao||null); return json(res,201,get('SELECT * FROM payments WHERE id=?',info.lastInsertRowid));
    }
    let pm=url.pathname.match(/^\/api\/pagamentos\/(\d+)$/);
    if(pm && req.method==='PATCH') {
      const old=get('SELECT * FROM payments WHERE id=?',pm[1]); if(!old) return json(res,404,{error:'Pagamento não encontrado'});
      const b=await body(req);
      db.prepare('UPDATE payments SET patient_id=?, payment_date=?, amount=?, notes=? WHERE id=?').run(
        b.patient_id!==undefined?Number(b.patient_id):old.patient_id,
        b.data!==undefined?b.data:old.payment_date,
        b.valor!==undefined?money(b.valor):old.amount,
        b.observacao!==undefined?b.observacao:old.notes,
        pm[1]);
      return json(res,200,get('SELECT * FROM payments WHERE id=?',pm[1]));
    }
    if(pm && req.method==='DELETE') { db.prepare('DELETE FROM payments WHERE id=?').run(pm[1]); return json(res,200,{ok:true}); }

    // Editable accounts payable / receivable
    if(url.pathname==='/api/contas' && req.method==='GET') {
      const type=url.searchParams.get('tipo');
      const sql=`SELECT f.*, p.name AS patient_name FROM financial_entries f LEFT JOIN patients p ON p.id=f.patient_id ${type?'WHERE f.type=?':''} ORDER BY COALESCE(f.due_date,'9999-12-31') DESC, f.id DESC`;
      return json(res,200,type?all(sql,type):all(sql));
    }
    if(url.pathname==='/api/contas' && req.method==='POST') {
      const b=await body(req);
      if(!['receber','pagar'].includes(b.tipo) || !String(b.descricao||'').trim() || b.valor==null) return json(res,400,{error:'Tipo, descrição e valor são obrigatórios'});
      const status=b.status||'Aberto';
      const info=db.prepare(`INSERT INTO financial_entries (type,description,amount,due_date,paid_date,status,patient_id,notes) VALUES (?,?,?,?,?,?,?,?)`).run(
        b.tipo,String(b.descricao).trim(),money(b.valor),b.vencimento||null,b.data_pagamento||null,status,b.patient_id?Number(b.patient_id):null,b.observacao||null);
      return json(res,201,get('SELECT * FROM financial_entries WHERE id=?',info.lastInsertRowid));
    }
    let cm=url.pathname.match(/^\/api\/contas\/(\d+)$/);
    if(cm && req.method==='PATCH') {
      const old=get('SELECT * FROM financial_entries WHERE id=?',cm[1]); if(!old) return json(res,404,{error:'Conta não encontrada'});
      const b=await body(req);
      db.prepare(`UPDATE financial_entries SET type=?,description=?,amount=?,due_date=?,paid_date=?,status=?,patient_id=?,notes=? WHERE id=?`).run(
        b.tipo||old.type,b.descricao!==undefined?String(b.descricao):old.description,b.valor!==undefined?money(b.valor):old.amount,
        b.vencimento!==undefined?(b.vencimento||null):old.due_date,b.data_pagamento!==undefined?(b.data_pagamento||null):old.paid_date,
        b.status||old.status,b.patient_id!==undefined?(b.patient_id?Number(b.patient_id):null):old.patient_id,b.observacao!==undefined?b.observacao:old.notes,cm[1]);
      return json(res,200,get('SELECT * FROM financial_entries WHERE id=?',cm[1]));
    }
    if(cm && req.method==='DELETE') { db.prepare('DELETE FROM financial_entries WHERE id=?').run(cm[1]); return json(res,200,{ok:true}); }

    // Finance drill-down and payment entry
    if(url.pathname==='/api/financeiro/previsao' && req.method==='GET') {
      const weeks=Math.max(1,Math.min(12,Number(url.searchParams.get('weeks')||4)));
      const today=new Date(); today.setHours(12,0,0,0);
      const day=today.getDay(); const daysToNextMonday=(8-day)%7 || 7;
      const start=new Date(today); start.setDate(start.getDate()+daysToNextMonday);
      const out=[];
      let total=0, qtd=0;
      for(let i=0;i<weeks;i++){
        const a=new Date(start); a.setDate(a.getDate()+i*7);
        const b=new Date(a); b.setDate(b.getDate()+6);
        const ini=isoDate(a), fim=isoDate(b);
        const rows=all(`SELECT s.id,s.session_date,s.session_time,s.value,s.status,p.name AS patient_name
          FROM sessions s JOIN patients p ON p.id=s.patient_id
          WHERE s.session_date BETWEEN ? AND ? AND s.status='Agendada' AND COALESCE(s.slot_removed,0)=0
          ORDER BY s.session_date,s.session_time,p.name`,ini,fim);
        const valor=rows.reduce((sum,x)=>sum+Number(x.value||0),0);
        total+=valor; qtd+=rows.length;
        out.push({inicio:ini,fim:fim,qtd:rows.length,valor,agendamentos:rows});
      }
      return json(res,200,{weeks,start:isoDate(start),total,qtd,periodos:out});
    }
    if(url.pathname==='/api/financeiro/resumo' && req.method==='GET') {
      const mes=url.searchParams.get('mes')||new Date().toISOString().slice(0,7);
      const atendimento=get(`SELECT COALESCE(SUM(CASE WHEN status='Realizada' THEN value ELSE 0 END),0) valor, COUNT(CASE WHEN status='Realizada' THEN 1 END) qtd FROM sessions WHERE substr(session_date,1,7)=?`,mes);
      const rec=get(`SELECT COALESCE(SUM(amount),0) valor, COUNT(*) qtd FROM payments WHERE substr(payment_date,1,7)=?`,mes);
      const realizadas=atendimento;
      const late=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND status='Cancelada em cima da hora' AND rescheduled_to_id IS NULL`,mes);
      const faltas=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND status='Faltou'`,mes);
      const reag=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND rescheduled_to_id IS NOT NULL`,mes);
      const antecip=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND status='Cancelada antecipadamente'`,mes);
      const unpaid=unpaidSessionRows();
      const due=unpaid.reduce((a,x)=>a+x.remaining,0);
      const today=new Date(); today.setHours(0,0,0,0); const cutoff=new Date(today); cutoff.setDate(cutoff.getDate()-30);
      const atrasados=unpaid.filter(x=>new Date(x.session_date+'T12:00:00')<=cutoff);
      return json(res,200,{mes,atendimento,devido:{valor:due,qtd:unpaid.length},recebimentos:rec,realizadas,canceladas_hora:late,faltas,reagendadas:reag,antecipadas:antecip,atrasados:{valor:atrasados.reduce((a,x)=>a+x.remaining,0),qtd:atrasados.length}});
    }
    if(url.pathname==='/api/financeiro/detalhes' && req.method==='GET') {
      const mes=url.searchParams.get('mes')||new Date().toISOString().slice(0,7), tipo=url.searchParams.get('tipo')||'recebimentos';
      if(tipo==='recebimentos') return json(res,200,all(`SELECT pg.id,pg.payment_date AS data,pg.amount AS valor,p.name AS paciente_name,pg.notes AS observacao FROM payments pg JOIN patients p ON p.id=pg.patient_id WHERE substr(pg.payment_date,1,7)=? ORDER BY p.name,pg.payment_date,pg.id`,mes));
      if(tipo==='devido'){
        const rows=unpaidSessionRows().sort((a,b)=>a.patient_name.localeCompare(b.patient_name)||a.session_date.localeCompare(b.session_date));
        return json(res,200,rows.map(x=>({id:x.id,data:x.session_date,horario:x.session_time,valor:x.remaining,valor_original:x.value,status:x.status,paciente_name:x.patient_name,observacao:x.notes,origem:'Sessão'})));
      }
      if(tipo==='atrasados'){
        const cutoff=new Date(); cutoff.setHours(0,0,0,0); cutoff.setDate(cutoff.getDate()-30);
        const rows=unpaidSessionRows().filter(x=>new Date(x.session_date+'T12:00:00')<=cutoff).sort((a,b)=>a.patient_name.localeCompare(b.patient_name)||a.session_date.localeCompare(b.session_date));
        return json(res,200,rows.map(x=>({id:x.id,data:x.session_date,horario:x.session_time,valor:x.remaining,status:x.status,paciente_name:x.patient_name,observacao:x.notes,dias:Math.floor((Date.now()-new Date(x.session_date+'T12:00:00').getTime())/86400000)})));
      }
      const map={realizadas:"status='Realizada'",canceladas_hora:"status='Cancelada em cima da hora' AND rescheduled_to_id IS NULL",faltas:"status='Faltou'",cancel_faltas:"status IN ('Cancelada em cima da hora','Faltou')",antecipadas:"status='Cancelada antecipadamente'",reagendadas:"rescheduled_to_id IS NOT NULL"};
      const where=map[tipo]||map.realizadas;
      const isYear=/^\d{4}$/.test(mes);
      const period=isYear?`substr(s.session_date,1,4)=?`:`substr(s.session_date,1,7)=?`;
      return json(res,200,all(`SELECT s.id,s.session_date AS data,s.session_time AS horario,s.value AS valor,s.status,p.name AS paciente_name,s.notes AS observacao FROM sessions s JOIN patients p ON p.id=s.patient_id WHERE ${period} AND ${where} ORDER BY p.name,s.session_date,s.session_time,s.id`,mes));
    }
    // Summaries
    if(url.pathname==='/api/resumo-semana' && req.method==='GET') {
      const start=url.searchParams.get('start'), end=url.searchParams.get('end'); if(!start||!end) return json(res,400,{error:'start e end são obrigatórios'});
      const s=get(`SELECT COUNT(*) total,
        COALESCE(SUM(CASE WHEN status='Realizada' THEN 1 ELSE 0 END),0) realizadas,
        COALESCE(SUM(CASE WHEN status='Cancelada em cima da hora' THEN 1 ELSE 0 END),0) cancel_hora,
        COALESCE(SUM(CASE WHEN status='Cancelada em cima da hora' THEN value ELSE 0 END),0) valor_cancel_hora,
        COALESCE(SUM(CASE WHEN status IN ('Cancelada antecipadamente','Cancelada em cima da hora','Faltou') AND rescheduled_to_id IS NOT NULL THEN 1 ELSE 0 END),0) cancel_reag,
        COALESCE(SUM(CASE WHEN status IN ('Cancelada antecipadamente','Cancelada em cima da hora','Faltou') AND rescheduled_to_id IS NOT NULL THEN value ELSE 0 END),0) valor_cancel_reag,
        COALESCE(SUM(CASE WHEN status='Faltou' THEN 1 ELSE 0 END),0) faltas,
        COALESCE(SUM(CASE WHEN status='Faltou' THEN value ELSE 0 END),0) valor_faltas,
        COALESCE(SUM(CASE WHEN status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN value ELSE 0 END),0) devido
        FROM sessions WHERE session_date BETWEEN ? AND ?`,start,end);
      return json(res,200,s);
    }
    if(url.pathname==='/api/resumo-ano' && req.method==='GET') {
      const ano=String(url.searchParams.get('ano')||new Date().getFullYear());
      const out=[];
      for(let i=1;i<=12;i++){
        const mes=`${ano}-${String(i).padStart(2,'0')}`;
        const atendimento=get(`SELECT COALESCE(SUM(CASE WHEN status='Realizada' THEN value ELSE 0 END),0) valor, COUNT(CASE WHEN status='Realizada' THEN 1 END) qtd FROM sessions WHERE substr(session_date,1,7)=?`,mes);
        const rec=get(`SELECT COALESCE(SUM(amount),0) valor, COUNT(*) qtd FROM payments WHERE substr(payment_date,1,7)=?`,mes);
        const late=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND status='Cancelada em cima da hora' AND rescheduled_to_id IS NULL`,mes);
        const faltas=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND status='Faltou'`,mes);
        const reag=get(`SELECT COALESCE(SUM(value),0) valor, COUNT(*) qtd FROM sessions WHERE substr(session_date,1,7)=? AND rescheduled_to_id IS NOT NULL`,mes);
        out.push({mes,atendimento_qtd:Number(atendimento.qtd||0),atendimento_valor:Number(atendimento.valor||0),sessoes_qtd:Number(atendimento.qtd||0),sessoes_valor:Number(atendimento.valor||0),recebimento:Number(rec.valor||0),cancel_hora_qtd:Number(late.qtd||0),cancel_hora_valor:Number(late.valor||0),faltas_qtd:Number(faltas.qtd||0),faltas_valor:Number(faltas.valor||0),reag_qtd:Number(reag.qtd||0),reag_valor:Number(reag.valor||0)});
      }
      const totals={
        atendimento_qtd:out.reduce((a,x)=>a+x.atendimento_qtd,0),atendimento_valor:out.reduce((a,x)=>a+x.atendimento_valor,0),
        sessoes_qtd:out.reduce((a,x)=>a+x.sessoes_qtd,0),sessoes_valor:out.reduce((a,x)=>a+x.sessoes_valor,0),
        recebimento:out.reduce((a,x)=>a+x.recebimento,0),
        cancel_hora_qtd:out.reduce((a,x)=>a+x.cancel_hora_qtd,0),cancel_hora_valor:out.reduce((a,x)=>a+x.cancel_hora_valor,0),
        faltas_qtd:out.reduce((a,x)=>a+x.faltas_qtd,0),faltas_valor:out.reduce((a,x)=>a+x.faltas_valor,0),
        reag_qtd:out.reduce((a,x)=>a+x.reag_qtd,0),reag_valor:out.reduce((a,x)=>a+x.reag_valor,0)
      };
      const historical=all(`SELECT substr(session_date,1,4) ano, COUNT(CASE WHEN status='Realizada' THEN 1 END) sessoes_qtd, COALESCE(SUM(CASE WHEN status='Realizada' THEN value ELSE 0 END),0) sessoes_valor FROM sessions WHERE substr(session_date,1,4)<>? GROUP BY substr(session_date,1,4) ORDER BY ano`,ano);
      return json(res,200,{ano,meses:out,totals,historical});
    }
    if(url.pathname==='/api/dashboard' && req.method==='GET') {
      const mes=url.searchParams.get('mes')||new Date().toISOString().slice(0,7);
      const s=get(`SELECT COUNT(*) total_sessoes,
        COALESCE(SUM(CASE WHEN status='Realizada' THEN value ELSE 0 END),0) faturado,
        COALESCE(SUM(CASE WHEN status IN ('Realizada','Cancelada em cima da hora','Faltou') THEN value ELSE 0 END),0) devido,
        COALESCE(SUM(CASE WHEN status='Realizada' THEN 1 ELSE 0 END),0) realizadas,
        COALESCE(SUM(CASE WHEN status='Cancelada antecipadamente' THEN 1 ELSE 0 END),0) canceladas,
        COALESCE(SUM(CASE WHEN status='Cancelada em cima da hora' THEN 1 ELSE 0 END),0) canceladas_hora,
        COALESCE(SUM(CASE WHEN status='Faltou' THEN 1 ELSE 0 END),0) faltas
        FROM sessions WHERE substr(session_date,1,7)=?`,mes);
      const r=get('SELECT COALESCE(SUM(amount),0) recebido FROM payments WHERE substr(payment_date,1,7)=?',mes);
      return json(res,200,{...s,recebido:r.recebido,saldo:Math.max(0,Number(s.devido||0)-Number(r.recebido||0))});
    }
    return json(res,404,{error:'Rota não encontrada'});
  } catch(e) { console.error(e); return json(res,500,{error:e.message}); }
}

const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(url.pathname.startsWith('/api/')) return api(req,res,url);
  const file=url.pathname==='/'?path.join(ROOT,'public','index.html'):path.join(ROOT,'public',url.pathname.replace(/^\/+/,''));
  if(!file.startsWith(path.join(ROOT,'public'))) return res.writeHead(403).end();
  fs.readFile(file,(err,data)=>{if(err)return res.writeHead(404).end('Not found');res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(data);});
});
server.listen(PORT,()=>console.log(`Consultório rodando em http://localhost:${PORT}`));
process.on('SIGINT',()=>{db.close();process.exit(0)});

# Consultório Psicologia — V26

Aplicativo local de gestão de consultório psicológico.

## Estrutura
- `app/` — código da aplicação
- `scripts/launcher.ps1` — inicia a aplicação e verifica atualizações
- `scripts/install.ps1` — instalação no Windows

## Dados
O banco de dados local (`consultorio.db`) **não faz parte deste repositório**. Os dados dos pacientes ficam na pasta `data/` da instalação local.

## Atualizações
O launcher consulta as Releases do GitHub e, quando existe uma versão mais nova, baixa o asset `consultorio-update.zip`, faz backup do banco e atualiza somente os arquivos do programa.
